Show how to create a object randomly picked in a list.
